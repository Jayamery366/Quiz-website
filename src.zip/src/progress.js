import React from 'react';
import { Card } from 'react-bootstrap';
import { Bar } from 'react-chartjs-2';
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend } from 'chart.js';
import { useNavigate, useLocation } from 'react-router-dom';

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend);

const ProgressComponent = () => {
  const navigate = useNavigate();
  const location = useLocation();
  

  const { level1Score, level1Questions, level2Score, level2Questions } = location.state || {
    level1Score: 0,
    level1Questions: 0,
    level2Score: 0,
    level2Questions: 0
  };

  const data = {
    labels: ['Level 1', 'Level 2'],
    datasets: [
      {
        label: 'Score',
        data: [level1Score, level2Score],
        backgroundColor: 'rgba(75, 192, 192, 0.6)',
      },
      {
        label: 'Total Questions',
        data: [level1Questions, level2Questions],
        backgroundColor: 'rgba(153, 102, 255, 0.6)',
      },
    ],
  };

  const options = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top',
      },
      title: {
        display: true,
        text: 'Quiz Progress',
      },
    },
  };

  return (
    <div className="progress-container">
      <Card style={{ width: '600px', margin: 'auto', padding: '20px' }}>
        <Card.Body>
          <h2>Your Progress</h2>
          <p>Level 1: {level1Score} / {level1Questions}</p>
          <p>Level 2: {level2Score} / {level2Questions}</p>
          <div style={{ marginTop: '30px' }}>
            <Bar data={data} options={options} />
          </div>
          <button onClick={() => navigate('/')}>Retake Quiz</button>
        </Card.Body>
      </Card>
    </div>
  );
};

export default ProgressComponent;
