 
import React, { useState } from 'react';
import { Card, Button, Row, Col } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';  
import './App.css';

const QuizComponent = () => {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [score, setScore] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState(null);
  const [questions, setQuestions] = useState([
    {
    question: '1.How many  are days are there in a week?',
    answers: [2,7,9,4],
    correctAnswer: 2
    },
    {
    question: '2.Rainbow consist of how many colours?',
    answers: [7,5,6,2],
    correctAnswer: 1
    },
    {
    question:'3.How many hours are there in a day?',
    answer:['24hrs','32hrs','78hrs','12hrs'],
    correctAnswer:1
    },
    {
    question:'4.4.How many days are there in a year(Not a leap year)?',
    answer:['120','670','40','365'],
    correctAnswer:4
    },
    {
    question:'How many seconds are there in a minute?',
    answer:['9sec','90sec','120','60sec'],
    correctAnswer:4
    },
  ]);

  const navigate = useNavigate(); 

  const handleAnswerSelection = (answerIndex) => {
    setSelectedAnswer(answerIndex);
  };

  const handleSubmit = () => {
    if (selectedAnswer !== null && selectedAnswer === questions[currentQuestion].correctAnswer) {
      setScore(score + 1);
    }

    if (currentQuestion + 1 < questions.length) {
      setCurrentQuestion(currentQuestion + 1);
      setSelectedAnswer(null);
    } else {
     
      if (score >= 1 && score <= 2) {
        navigate('/level2');  
      } else {
        navigate('/exit'); 
      }
    }
  };
  
  const QuizComponent = () => {
    const [currentQuestion, setCurrentQuestion] = useState(0);
    const [score, setScore] = useState(0);
    const [selectedAnswer, setSelectedAnswer] = useState(null);
    const [questions, setQuestions] = useState([
        {
        question: 'Where is the world\'s tallest building located?',
        answers: ['Africa', 'California', 'Dubai', 'Italy'],
        correctAnswer: 2
        },
        {
        question:'1.How many vowels are there in the English alphabet?',
        answer:[5,10,23, 9],
        correctAnswer:1
        },
        {
        question:'2.Which animal is known as the king of the jungle?',
        answers:['Lion','Tiger','answers,','Zebra'],
        correctAnswer:1
        },
        {
        question:'3.What is the National Anthem of India?',
        answer:['Jana Gana Mana', 'Vande Mataram', 'Both A & B','None of the above'],
        },
        {
        question:'4.Is Asia is the biggest continent in the world?',
        answer:['TRUE','FALSE'],
        },
        {
        question:'5.How many continents are there in the world?',
        answer:[1,5,10,7],
        correctAnswer:4
        },

    ]);
  
    const navigate = useNavigate(); 
  
    const handleAnswerSelection = (answerIndex) => {
      setSelectedAnswer(answerIndex);
    };
  
    const handleSubmit = () => {
      if (selectedAnswer !== null && selectedAnswer === questions[currentQuestion].correctAnswer) {
        setScore(score + 1);
      }
  
      if (currentQuestion + 1 < questions.length) {
        setCurrentQuestion(currentQuestion + 1);
        setSelectedAnswer(null);
      } else {
       
        if (score >= 1 && score <= 2) {
          navigate('/level3');  
        } else {
          navigate('/exit'); 
        }
      }
    };
        const QuizComponent = () => {
        const [currentQuestion, setCurrentQuestion] = useState(0);
        const [score, setScore] = useState(0);
        const [selectedAnswer, setSelectedAnswer] = useState(null);
        const [questions, setQuestions] = useState([
            {
            question: '1.How many years are there in one Millenium?',
            answers: ['100-Years','10-Years','1000-Years','1-Year'],
            correctAnswer: 2
            },
            {
            question:'2.Name a bird that lays the largest eggs?',
            answers: ['Ostrich','Hen','Peacock','Pigeon'],
            correctAnswer:1
            },
            {
            question:'3.Anti-clockwise is it from left or right?',
            answers:['Left', 'Right', 'Both','None'],
            correctAnswer:1
            },
            {
            question:'4.Is Sun is the principal source of energy for the Earth?',
            answer:['True','False'],
            },
            {
            question:'Name the longest river on the Earth?',
            answer:['Nile','Indus', 'Kaveri', 'Krishna'],
            },
    
        ]);
  return (
    <div className="quiz-container" style={{ textAlign: 'center', marginTop: '50px' }}>
      <div style={{ marginBottom: '20px' }}>
        <h4>Question: {currentQuestion}/{questions.length}</h4>
      </div>

      {currentQuestion < questions.length ? (
        <Card className="quiz-card" style={{ width: '400px', margin: 'auto', padding: '20px' }}>
          <Card.Body>
            <Card.Title>{questions[currentQuestion].question}</Card.Title>

            <Row>
              {questions[currentQuestion].answers.map((answer, index) => (
                <Col xs={6} key={index} style={{ marginBottom: '15px' }}>
                  <Button
                    variant={selectedAnswer === index ? 'primary' : 'outline-primary'}
                    onClick={() => handleAnswerSelection(index)}
                    style={{ width: '100%' }}
                  >
                    {answer}
                  </Button>
                </Col>
              ))}
            </Row>

            <Button
              variant="success"
              onClick={handleSubmit}
              disabled={selectedAnswer === null}
              style={{ marginTop: '20px' }}
            >
              Next Question
            </Button>
          </Card.Body>
        </Card>
      ) : (
        <Card className="quiz-card" style={{ width: '400px', margin: 'auto', padding: '20px' }}>
          <Card.Body>
            <h2>Quiz Complete!</h2>
            <p>Your score is {score} out of {questions.length}</p>
            <Button href="level2">Level2</Button>
          </Card.Body>
        </Card>
      )}
    </div>
  );
};
  }
}
export default QuizComponent;