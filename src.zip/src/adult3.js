import React, { useState } from 'react';
import { Card, Button, Row, Col } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';
import './App.css';

const QuizComponent3 = () => {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [score, setScore] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState(null);
  const [questions] = useState([
    {
      question: '1.Who among the following has designed the PHP programing language?',
      answers: ['Rasmus Lerdorf','Guido van Rossum','Brendan Eich','James Gosling'],
      correctAnswer: 0
    },
   {
    question:'2.The information stored in a computer is known as?',
    answers:['Facts','Files','Data','Directory or Repository'],
    correctAnswer: 0
   },
   {
   question: '3.Which among the following is known as point-and-draw device?',
   answers:['Keyboard','Scanner','Mouse','CPU'],
   correctAnswer: 3
   },
  ]);

  const navigate = useNavigate();

  const handleAnswerSelection = (answerIndex) => {
    setSelectedAnswer(answerIndex);
  };

  const handleSubmit = () => {
    if (selectedAnswer !== null && selectedAnswer === questions[currentQuestion].correctAnswer) {
      setScore(score + 1);
    }
    setCurrentQuestion(currentQuestion + 1);
    setSelectedAnswer(null);
  };

  const handleViewProgress = () => {
    navigate('/progress', { 
      state: { 
        level1Score: score, 
        level1Questions: questions.length 
      } 
    });
  };

  const handleExit = () => {
    navigate('/thank'); 
  };

  return (
    <div className="quiz-container" style={{ textAlign: 'center', marginTop: '50px' }}>
      <div style={{ marginBottom: '20px' }}>
        <h4>Question: {currentQuestion + 1}/{questions.length}</h4>
      </div>

      {currentQuestion < questions.length ? (
        <Card className="quiz-card" style={{ width: '400px', margin: 'auto', padding: '20px' }}>
          <Card.Body>
            <Card.Title>{questions[currentQuestion].question}</Card.Title>

            <Row>
              {questions[currentQuestion].answers.map((answer, index) => (
                <Col xs={6} key={index} style={{ marginBottom: '15px' }}>
                  <Button
                    variant={selectedAnswer === index ? 'primary' : 'outline-primary'}
                    onClick={() => handleAnswerSelection(index)}
                    style={{ width: '100%' }}
                  >
                    {answer}
                  </Button>
                </Col>
              ))}
            </Row>

            <Button
              variant="success"
              onClick={handleSubmit}
              disabled={selectedAnswer === null}
              style={{ marginTop: '20px' }}
            >
              Next Question
            </Button>
          </Card.Body>
        </Card>
      ) : (
        <Card className="quiz-card" style={{ width: '400px', margin: 'auto', padding: '20px' }}>
          <Card.Body>
            <h2>Quiz Complete!</h2>
            <p>Your score is {score} out of {questions.length}</p>
            <Button variant="primary" onClick={handleExit} style={{ marginTop: '10px' }}>
              Submit
            </Button>
          </Card.Body>
        </Card>
      )}
    </div>
  );
};

export default QuizComponent3;
