import React, { useState } from 'react';
import QuizComponent from './level1';

const ParentComponent = () => {
  const [score, setScore] = useState(0);
  const totalQuestions = 2; // Adjust based on the total number of questions

  return (
    <div>
      <QuizComponent setScore={setScore} totalQuestions={totalQuestions} />
    </div>
  );
};

export default ParentComponent;
