function Imagesection() {
    return (
      <center>
       <img  src="/logo.jpeg"/>
       <h1>Login</h1>
      </center>
    );
  }
  export default Imagesection;