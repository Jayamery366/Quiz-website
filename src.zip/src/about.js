import React from 'react';
import './App.css'; 
import Header from './header';

function About() {
  return (
    <div className="about-background">
      <Header/>
      <div className="container text-light p-5">
        <h2>About Us</h2><br/><br/>
        <h4>Empowering Students of All Ages to Test Their Knowledge!</h4>
        <p >
          At QuizMaster, we believe that learning should be both fun and challenging. 
          Our platform is designed to offer students of different age groups an opportunity to take quizzes suited to their knowledge level. 
          Whether you're below or above 13 years old, we've got something exciting for you!
        </p>
        <h5>For Students Under 13:</h5>
        <p>
          Explore our easy quizzes specially crafted to help you learn while having fun! 
          These quizzes focus on key subjects with engaging questions to spark curiosity and enhance understanding.
        </p>
        <h5>For Students 13 and Above:</h5>
        <p >
          Are you ready for a challenge? Test your knowledge with quizzes that come with increasing difficulty levels. 
          Each quiz is designed to stimulate critical thinking, help you improve, and prepare you for more advanced topics.
        </p>
      </div>
    </div>
  );
}

export default About;
