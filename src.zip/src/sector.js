import { useNavigate } from 'react-router-dom';

function Sector() {
    const navigate = useNavigate();

    const styles = {
        container: {
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            height: '100vh', 
            backgroundImage: 'url(https://marketingaccesspass.com/wp-content/uploads/2015/10/Podcast-Website-Design-Background-Image-1024x553.jpg)',
            backgroundSize: 'cover', 
            backgroundPosition: 'center', 
        },
        button: {
            border: 'none',
            padding: '10px',
            backgroundColor: 'transparent',
            cursor: 'pointer',
        },
        image: {
            width: '350px',
            height: '350px',
            objectFit: 'cover',
            borderRadius: '10px',
            margin: '0 10px',
            transition: 'transform 0.3s ease',
        },
        heading: {
            color: 'white',
            textAlign: 'center',
        }
    };

    const handleClick = (route) => {
        navigate(route);
    };

    return (
        <div style={styles.container}>
            <button 
                style={styles.button} 
                onClick={() => handleClick('/Adult')}
            >
                <img 
                    src="https://www.learningspiral.co.in/wp-content/uploads/2018/10/1_s2gaubfe9q4qIIG6QYGibQ.png" 
                    alt="First" 
                    style={styles.image} 
                    onMouseEnter={(e) => e.target.style.transform = 'scale(1.1)'}
                    onMouseLeave={(e) => e.target.style.transform = 'scale(1)'}
                />
                <h3 style={styles.heading}>Above 13 age</h3>
            </button>
            <button 
                style={styles.button} 
                onClick={() => handleClick('/ImageButtons')}
            >
                <img 
                    src="https://assets-global.website-files.com/64bfe3c4de68c5440a032df9/65e514cb30d678f5fbdf5755_pexels-andrea-piacquadio-3768166.jpg" 
                    alt="Second" 
                    style={styles.image} 
                    onMouseEnter={(e) => e.target.style.transform = 'scale(1.1)'}
                    onMouseLeave={(e) => e.target.style.transform = 'scale(1)'}
                />
                <h3 style={styles.heading}>Below 13 age</h3>
            </button>
        </div>
    );
}

export default Sector;
