import React from 'react';
import Button from 'react-bootstrap/Button';
import { Link } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';

function Header() {
  return (
    <div className="text-center">
      <Link to="/home">
        <Button variant="light" className="m-2">Home</Button>
      </Link>
      <Link to="/about">
        <Button variant="light" className="m-2">About Us</Button>
      </Link>
      <Link to="/login">
        <Button variant="light" className="m-2">Login</Button>
      </Link>
      <Link to="/register">
        <Button variant="light" className="m-2">Register</Button>``
      </Link>
    </div>
  );
}

export default Header;
