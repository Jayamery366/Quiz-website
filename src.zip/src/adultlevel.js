import React from 'react';
import './App.css';

function Adult() {
  const buttonData = [
    { href: '/adult1', image: 'https://www.shutterstock.com/image-photo/woman-smile-writing-cafe-laptop-600nw-2472683605.jpg', alt: 'Level-1', title: 'Level 1' },
    { href: '/adult2', image: 'https://www.shutterstock.com/image-photo/serious-student-alaptop-thinking-looking-600nw-2476602873.jpg', alt: 'Level-2', title: 'Level 2' },
    { href: '/adult3', image: 'https://www.shutterstock.com/image-photo/focused-clever-male-student-university-260nw-2175840737.jpg', alt: 'Level-3', title: 'Level 3' },
  ];

  return (
    <div className="center">
      {buttonData.map((button) => (
        <div key={button.href} className="image-button">
          <a href={button.href}>
            <img src={button.image} alt={button.alt} className="button-image" />
          </a>
          <h3 className="image-title">{button.title}</h3>
        </div>
      ))}
    </div>
  );
}

export default Adult;
