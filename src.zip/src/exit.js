import React from 'react';
import Button from 'react-bootstrap/Button';
import { Link } from 'react-router-dom';  

function Exit() {
  return (
    <div style={{ textAlign: 'center', marginTop: '50px' }}>
      <style>
        {`
          .exit-text {
            color: white;
          }
        `}
      </style>
      <h1 className="exit-text">Thank You For Writing This Quiz</h1>
      <p className="exit-text">Please write next Level</p>
      <Link to="/ImageButtons">
        <Button variant="light" className="m-2">Back</Button>
      </Link>  
    </div>
  );
}

export default Exit;
