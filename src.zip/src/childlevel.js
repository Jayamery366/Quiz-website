import React from 'react';
import './App.css';

function ImageButtons() {
  const buttonData = [
    { href: '/child1', image: 'https://www.shutterstock.com/image-photo/side-view-child-writing-spiral-600nw-1872432829.jpg', alt: 'Level-1', title: 'Level 1' },
    { href: '/child2', image: 'https://static.toiimg.com/photo/84174489.jpg', alt: 'Level-2', title: 'Level 2' },
    { href: '/child3', image: 'https://www.shutterstock.com/image-photo/kid-boy-glasses-learning-home-600nw-2430570317.jpg', alt: 'Level-3', title: 'Level 3' },
  ];

  return (
    <div className="center">
      {buttonData.map((button) => (
        <div key={button.href} className="image-button">
          <a href={button.href}>
            <img src={button.image} alt={button.alt} className="button-image" />
          </a>
          <h3 className="image-title">{button.title}</h3>
        </div>
      ))}
    </div>
  );
}

export default ImageButtons;
