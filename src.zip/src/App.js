import React from 'react';
import './App.css';
import Reg from './reg.js';
import Login from './login.js';
import Home from './home.js'
import About from './about.js'
import Sector from './sector.js'
import Exit from './exit'
import Exit1 from './exit1'
import Adult from './adultlevel.js'
import ImageButtons from './childlevel.js'
import QuizComponent from './adult1.js'
import QuizComponent2 from './adult2.js'
import QuizComponent3 from './adult3.js'
import Child1 from './child1.js'
import Child2 from './child2.js'
import Child3 from './child3.js'
import Thank from './thank.js'

import { BrowserRouter ,Routes,Route} from "react-router-dom";

function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
          <Route path="/register" element={<Reg/>} />
          <Route path="/login" element={<Login/>} />
          <Route path="/home" element={<Home/>} />
          <Route path="/about" element={<About/>} />
          <Route path="/sector" element={<Sector/>} />
          <Route path="/exit" element={<Exit/>}/>
          <Route path="/exit1" element={<Exit1/>}/>
          <Route path="/adult" element={<Adult/>}/>
          <Route path="/adult1" element={<QuizComponent/>}/>
          <Route path="/adult2" element={<QuizComponent2/>}/>
          <Route path="/adult3" element={<QuizComponent3/>}/>
          <Route path="/ImageButtons" element={<ImageButtons/>}/>
          <Route path="/child1" element={<Child1/>}/>
          <Route path="/child2" element={<Child2/>}/>
          <Route path="/child3" element={<Child3/>}/>
          <Route path="/thank" element={<Thank/>}/>
          
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
