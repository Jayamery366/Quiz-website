import React, { useState } from 'react';
import { Card, Button, Row, Col } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';
import './App.css';

const QuizComponent1 = () => {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [score, setScore] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState(null);
  const [questions] = useState([
    {
      question: 'Where is the world\'s tallest building located?',
      answers: ['Africa', 'California', 'Dubai', 'Italy'],
      correctAnswer: 2
    },
    {
      question: 'What is the capital of France?',
      answers: ['Paris', 'London', 'Berlin', 'Rome'],
      correctAnswer: 0
    },
  ]);

  const navigate = useNavigate();

  const handleAnswerSelection = (answerIndex) => {
    setSelectedAnswer(answerIndex);
  };

  const handleSubmit = () => {
    if (selectedAnswer !== null && selectedAnswer === questions[currentQuestion].correctAnswer) {
      setScore(score + 1);
    }
    setCurrentQuestion(currentQuestion + 1);
    setSelectedAnswer(null);
  };

  const handleViewProgress = () => {
    navigate('/progress', { 
      state: { 
        level1Score: score.QuizComponent, 
        level1Questions: 5, 
        level2Score: score.QuizComponent1, 
        level2Questions: 5 
      } 
    });
  };

  return (
    <div className="quiz-container" style={{ textAlign: 'center', marginTop: '50px' }}>
      <div style={{ marginBottom: '20px' }}>
        <h4>Question: {currentQuestion + 1}/{questions.length}</h4>
      </div>

      {currentQuestion < questions.length ? (
        <Card className="quiz-card" style={{ width: '400px', margin: 'auto', padding: '20px' }}>
          <Card.Body>
            <Card.Title>{questions[currentQuestion].question}</Card.Title>

            <Row>
              {questions[currentQuestion].answers.map((answer, index) => (
                <Col xs={6} key={index} style={{ marginBottom: '15px' }}>
                  <Button
                    variant={selectedAnswer === index ? 'primary' : 'outline-primary'}
                    onClick={() => handleAnswerSelection(index)}
                    style={{ width: '100%' }}
                  >
                    {answer}
                  </Button>
                </Col>
              ))}
            </Row>

            <Button
              variant="success"
              onClick={handleSubmit}
              disabled={selectedAnswer === null}
              style={{ marginTop: '20px' }}
            >
              Next Question
            </Button>
          </Card.Body>
        </Card>
      ) : (
        <Card className="quiz-card" style={{ width: '400px', margin: 'auto', padding: '20px' }}>
          <Card.Body>
            <h2>Quiz Complete!</h2>
            <p>Your score is {score} out of {questions.length}</p>
            <Button variant="info" onClick={handleViewProgress} style={{ marginTop: '20px' }}>
              View Progress
            </Button>
          </Card.Body>
        </Card>
      )}
    </div>
  );
};

export default QuizComponent1;
