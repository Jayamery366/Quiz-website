import React, { useState } from 'react';
import { Card, CardBody, Form, Button } from 'react-bootstrap';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';  

function Register() {
  const [UserName, setUserName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  const navigate = useNavigate(); 

  function task(event) {
    setUserName(event.target.value);
  }
  function task1(event1) {
    setEmail(event1.target.value);
  }
  function task2(event2) {
    setPassword(event2.target.value);
  }
  function task3(event2) {
    setConfirmPassword(event2.target.value);
  }

  function display() {
    return axios.post("http://localhost:3001/create", {
      "username": UserName,
      "email": email,
      "password": password,
      "confirmpassword": confirmPassword
    })
    .then(result => {
      console.log(result);
      navigate("/login");  
    })
    .catch(err => {
      console.log(err);
    });
  }

  const handleSubmit = (event) => {
    event.preventDefault();
    display(); 
  };

  return (
    <Card className="register-card">
      <CardBody>
        <h2 className="register-heading">CREATE ACCOUNT</h2>
        <Form onSubmit={handleSubmit}>
          <Form.Group controlId="formBasicUserName">
            <Form.Control 
              onChange={task} 
              type="text" 
              placeholder="Enter your Username" 
              value={UserName}  
            />
          </Form.Group> 
          <Form.Group controlId="formBasicEmail"><br/>
            <Form.Control 
              onChange={task1} 
              type="email" 
              placeholder="Enter your email" 
              value={email}  
            />
          </Form.Group>
          <Form.Group controlId="formBasicPassword"><br/>
            <Form.Control 
              onChange={task2} 
              type="password" 
              placeholder="Enter your password" 
            />
          </Form.Group>
          <Form.Group controlId="formBasicConfirmPassword"><br/>
            <Form.Control 
              onChange={task3} 
              type="password" 
              placeholder="Repeat your password"  
            />
          </Form.Group><br/>
          <Form.Check 
            type="checkbox" 
            label="I agree all statements in Terms of service" 
          />
          <Button variant="primary" type="submit">
            SIGN UP
          </Button>
        </Form>
        <p className="login-link">
          Have already an account? <a href="/login">Login here</a>
        </p>
      </CardBody>
    </Card>
  );
}

export default Register;
