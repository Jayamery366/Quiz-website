import React from 'react';
import Header from './header';
import 'bootstrap/dist/css/bootstrap.min.css'; 
import './App.css'; 

function Home() {
  return (
    <div className="home-background">
          <Header/>
     </div>
  );
}

export default Home;
