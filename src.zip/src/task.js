import { useState } from 'react';
import './App.css';
import axios from 'axios';
function Test() {
  const [A, setA] = useState("")
  const [B, setB] = useState("")
  const [C, setC] = useState("")

  function task(event) {
    setA(event.target.value)
  }
  function task1(event1) {
    setB(event1.target.value)
  }
  function task2(event2) {
    setC(event2.target.value)
  }
  function display() {
    axios.post("http://localhost:3001/create", {
        "title": A,
        "sub_title": B,
        "description": C

    }).then(result => {
        console.log(result)
    }).catch(err => {
        console.log(err)
    })
}
  return (
    <div>
      title
      <input onChange={task} type="text" placeholder="" /><br/>
      subtitle
      <input onChange={task1} type="" placeholder="" /><br/>
      description
      <input onChange={task2} type="" placeholder="" /><br/>
      <button onClick={display} >Submit</button>
    </div>
  )
}
export default Test;