import React, { useState } from 'react';
import { Card, Form, Button } from 'react-bootstrap';
import axios from 'axios';
import { Link } from "react-router-dom";
import { useNavigate } from 'react-router-dom';  

function Login() {
  const [UserName, setUserName] = useState('');
  const [password, setPassword] = useState('');
  const [msg, setMsg] = useState("");
  const navigate = useNavigate();  

  function task(event) {
    setUserName(event.target.value);
  }

  function task1(event1) {
    setPassword(event1.target.value);
  }

  function Submit() {
    axios.post('http://localhost:3001/find', {
        username: UserName,
        password:password
    }).then(result => {
        if (result.data.length !== 0) {
            if (result.data[0].password === password) {
                setMsg("Login Success");
                navigate('/Sector'); 
            } else {
                setMsg("Password is incorrect");
            }
        } else {
            setMsg("User ID is incorrect");
        }
    }).catch(err => {
        console.log("Error", err);
    });
  }

  const handleSubmit = (event) => {
    event.preventDefault();
  };

  return (
    <Card className="register-card">
      <Card.Body>
        <h2 className="register-heading">LOGIN ACCOUNT</h2>
        <br></br>
        <Form onSubmit={handleSubmit}>
          <Form.Group controlId="formBasicUserName">
            <Form.Control
              onChange={task}
              type="text"
              placeholder="Enter your Username"
              value={UserName}
            />
          </Form.Group>
          <Form.Group controlId="formBasicPassword">
            <br />
            <Form.Control
              onChange={task1}
              type="password" 
              placeholder="Enter your password"
              value={password}
            />
            <br></br>
          </Form.Group>
          <Button onClick={Submit}>Sign In</Button><br />
          <br></br>
        </Form>
        <p>NO Accout No worries! <Link to='/register'>Sign-up</Link></p>
        <p>{msg}</p> 
      </Card.Body>
    </Card>
  );
}

export default Login;
